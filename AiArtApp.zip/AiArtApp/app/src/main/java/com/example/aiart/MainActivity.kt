package com.example.aiart

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import kotlin.random.Random

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    AiArtScreen()
                }
            }
        }
    }
}

// ---------------------------------------------------------------------------
// Styles and sizes
// ---------------------------------------------------------------------------

data class ArtStyle(val label: String, val promptSuffix: String)

val artStyles = listOf(
    ArtStyle(
        "Oil painting",
        "oil painting, thick visible brushstrokes, rich colours, textured canvas, classical fine art"
    ),
    ArtStyle(
        "Watercolour",
        "watercolour painting, soft translucent washes, wet-on-wet blending, textured watercolour paper"
    ),
    ArtStyle(
        "Pencil",
        "graphite pencil drawing, detailed shading and cross-hatching, sketchbook paper, monochrome"
    ),
    ArtStyle(
        "Pen",
        "pen and ink drawing, fine linework, hatching and stippling, black ink on white paper"
    ),
    ArtStyle(
        "NFT art",
        "digital collectible NFT art, bold stylised character, vibrant colours, crisp clean vector style, simple background"
    ),
    ArtStyle(
        "Clay / plaster wall art",
        "textured clay and plaster wall art, hand-sculpted relief, raised surface, matte earthy tones, soft shadows"
    )
)

data class ArtSize(val label: String, val width: Int, val height: Int)

val artSizes = listOf(
    ArtSize("Square", 768, 768),
    ArtSize("Portrait", 768, 1024),
    ArtSize("Landscape", 1024, 768)
)

// ---------------------------------------------------------------------------
// History: each generated image is kept in the app's private storage, with a
// small JSON index holding the prompt, style and shape. The newest 50 are kept.
// ---------------------------------------------------------------------------

data class HistoryItem(val id: Long, val prompt: String, val style: String, val size: String)

object HistoryStore {
    private const val MAX_ITEMS = 50

    private fun dir(c: Context): File = File(c.filesDir, "history").also { it.mkdirs() }
    private fun indexFile(c: Context) = File(dir(c), "index.json")
    private fun imageFile(c: Context, id: Long) = File(dir(c), "$id.jpg")

    fun load(c: Context): List<HistoryItem> {
        val f = indexFile(c)
        if (!f.exists()) return emptyList()
        return try {
            val arr = JSONArray(f.readText())
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                HistoryItem(o.getLong("id"), o.getString("prompt"), o.getString("style"), o.getString("size"))
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    private fun write(c: Context, items: List<HistoryItem>) {
        val arr = JSONArray()
        items.forEach {
            arr.put(
                JSONObject()
                    .put("id", it.id)
                    .put("prompt", it.prompt)
                    .put("style", it.style)
                    .put("size", it.size)
            )
        }
        indexFile(c).writeText(arr.toString())
    }

    fun add(c: Context, bitmap: Bitmap, item: HistoryItem): List<HistoryItem> {
        imageFile(c, item.id).outputStream().use { bitmap.compress(Bitmap.CompressFormat.JPEG, 92, it) }
        val all = listOf(item) + load(c)
        val kept = all.take(MAX_ITEMS)
        all.drop(MAX_ITEMS).forEach { imageFile(c, it.id).delete() }
        write(c, kept)
        return kept
    }

    fun delete(c: Context, id: Long): List<HistoryItem> {
        imageFile(c, id).delete()
        val items = load(c).filter { it.id != id }
        write(c, items)
        return items
    }

    fun bitmap(c: Context, id: Long, sampleSize: Int = 1): Bitmap? {
        val opts = BitmapFactory.Options().apply { inSampleSize = sampleSize }
        return BitmapFactory.decodeFile(imageFile(c, id).path, opts)
    }
}

// ---------------------------------------------------------------------------
// Image service. Pollinations' anonymous tier needs no key but is rate limited
// (roughly one request every 15 seconds). To use another provider, change
// buildUrl/fetchImage and keep any API key on a server you control, not in the APK.
// ---------------------------------------------------------------------------

private fun buildUrl(prompt: String, style: ArtStyle, size: ArtSize, seed: Int): String {
    val full = "$prompt, ${style.promptSuffix}"
    val encoded = URLEncoder.encode(full, "UTF-8").replace("+", "%20")
    return "https://image.pollinations.ai/prompt/$encoded" +
        "?width=${size.width}&height=${size.height}&nologo=true&seed=$seed"
}

private suspend fun fetchImage(url: String): Bitmap = withContext(Dispatchers.IO) {
    val conn = URL(url).openConnection() as HttpURLConnection
    conn.connectTimeout = 15_000
    conn.readTimeout = 120_000
    try {
        if (conn.responseCode != 200) {
            error("Server returned ${conn.responseCode}. If it says 429, wait about 15 seconds and try again.")
        }
        BitmapFactory.decodeStream(conn.inputStream) ?: error("Could not read the image")
    } finally {
        conn.disconnect()
    }
}

private fun saveToGallery(context: Context, bitmap: Bitmap): Uri? {
    val values = ContentValues().apply {
        put(MediaStore.Images.Media.DISPLAY_NAME, "ai_art_${System.currentTimeMillis()}.png")
        put(MediaStore.Images.Media.MIME_TYPE, "image/png")
        put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/AiArt")
    }
    val uri = context.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
        ?: return null
    val out = context.contentResolver.openOutputStream(uri) ?: return null
    out.use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }
    return uri
}

private fun shareImage(context: Context, uri: Uri) {
    val intent = Intent(Intent.ACTION_SEND).apply {
        type = "image/png"
        putExtra(Intent.EXTRA_STREAM, uri)
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    context.startActivity(Intent.createChooser(intent, "Share image"))
}

// ---------------------------------------------------------------------------
// UI
// ---------------------------------------------------------------------------

@Composable
fun AiArtScreen() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var showHistory by remember { mutableStateOf(false) }
    var history by remember { mutableStateOf(HistoryStore.load(context)) }

    var prompt by remember { mutableStateOf("") }
    var style by remember { mutableStateOf(artStyles[0]) }
    var size by remember { mutableStateOf(artSizes[0]) }
    var bitmap by remember { mutableStateOf<Bitmap?>(null) }
    var savedUri by remember { mutableStateOf<Uri?>(null) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    fun generate() {
        if (prompt.isBlank() || loading) return
        loading = true
        error = null
        scope.launch {
            try {
                val usedPrompt = prompt.trim()
                val url = buildUrl(usedPrompt, style, size, Random.nextInt(1, 1_000_000))
                val bmp = fetchImage(url)
                bitmap = bmp
                savedUri = null
                history = withContext(Dispatchers.IO) {
                    HistoryStore.add(
                        context,
                        bmp,
                        HistoryItem(System.currentTimeMillis(), usedPrompt, style.label, size.label)
                    )
                }
            } catch (e: Exception) {
                error = e.message ?: "Something went wrong"
            } finally {
                loading = false
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("AI Art Generator", style = MaterialTheme.typography.headlineMedium)

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(
                selected = !showHistory,
                onClick = { showHistory = false },
                label = { Text("Create") }
            )
            FilterChip(
                selected = showHistory,
                onClick = { showHistory = true },
                label = { Text("History (${history.size})") }
            )
        }

        if (showHistory) {
            if (history.isEmpty()) {
                Text("No images yet. Create one and it will appear here.")
            } else {
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(history, key = { it.id }) { item ->
                        val thumb by produceState<Bitmap?>(null, item.id) {
                            value = withContext(Dispatchers.IO) { HistoryStore.bitmap(context, item.id, 4) }
                        }
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    scope.launch {
                                        val full = withContext(Dispatchers.IO) {
                                            HistoryStore.bitmap(context, item.id)
                                        }
                                        if (full != null) {
                                            bitmap = full
                                            savedUri = null
                                            error = null
                                            prompt = item.prompt
                                            style = artStyles.firstOrNull { it.label == item.style } ?: style
                                            size = artSizes.firstOrNull { it.label == item.size } ?: size
                                            showHistory = false
                                        }
                                    }
                                },
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            val t = thumb
                            if (t != null) {
                                Image(
                                    bitmap = t.asImageBitmap(),
                                    contentDescription = null,
                                    modifier = Modifier.size(80.dp),
                                    contentScale = ContentScale.Crop
                                )
                            } else {
                                Column(modifier = Modifier.size(80.dp)) {}
                            }
                            Column(modifier = Modifier.weight(1f)) {
                                Text(item.prompt, maxLines = 2, style = MaterialTheme.typography.bodyMedium)
                                Text(
                                    "${item.style} · ${item.size}",
                                    style = MaterialTheme.typography.labelSmall
                                )
                            }
                            TextButton(onClick = {
                                scope.launch {
                                    history = withContext(Dispatchers.IO) {
                                        HistoryStore.delete(context, item.id)
                                    }
                                }
                            }) {
                                Text("Delete")
                            }
                        }
                    }
                }
            }
        } else {
            Column(
                modifier = Modifier
                    .weight(1f)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedTextField(
                    value = prompt,
                    onValueChange = { prompt = it },
                    label = { Text("Describe the image you want") },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 2
                )

                Text("Style", style = MaterialTheme.typography.titleSmall)
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    artStyles.forEach { s ->
                        FilterChip(
                            selected = s == style,
                            onClick = { style = s },
                            label = { Text(s.label) }
                        )
                    }
                }

                Text("Shape", style = MaterialTheme.typography.titleSmall)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    artSizes.forEach { s ->
                        FilterChip(
                            selected = s == size,
                            onClick = { size = s },
                            label = { Text(s.label) }
                        )
                    }
                }

                Button(
                    onClick = { generate() },
                    enabled = prompt.isNotBlank() && !loading,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(if (bitmap == null) "Generate" else "Generate again")
                }

                if (loading) {
                    CircularProgressIndicator(modifier = Modifier.align(Alignment.CenterHorizontally))
                }

                error?.let {
                    Text(it, color = MaterialTheme.colorScheme.error)
                }

                bitmap?.let { bmp ->
                    Image(
                        bitmap = bmp.asImageBitmap(),
                        contentDescription = "Generated image",
                        modifier = Modifier
                            .fillMaxWidth()
                            .aspectRatio(bmp.width.toFloat() / bmp.height.toFloat())
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = {
                            if (savedUri != null) {
                                Toast.makeText(context, "Already saved", Toast.LENGTH_SHORT).show()
                            } else {
                                val uri = saveToGallery(context, bmp)
                                savedUri = uri
                                Toast.makeText(
                                    context,
                                    if (uri != null) "Saved to Pictures/AiArt" else "Could not save",
                                    Toast.LENGTH_SHORT
                                ).show()
                            }
                        }) {
                            Text("Save to gallery")
                        }
                        OutlinedButton(onClick = {
                            val uri = savedUri ?: saveToGallery(context, bmp).also { savedUri = it }
                            if (uri != null) shareImage(context, uri)
                            else Toast.makeText(context, "Could not share", Toast.LENGTH_SHORT).show()
                        }) {
                            Text("Share")
                        }
                    }
                }
            }
        }
    }
}
